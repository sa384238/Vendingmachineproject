//As we have no external database so taken inmemory array to store list of purchased products
const list = [];

function Insert(event) {
    var clickedId = event.target.id;
    var Message = "successful ";
    var coinAmount = document.getElementById("Coin").value;
    //The following element are usuable to display messages
    var errorMessageDiv = document.getElementById("Error");
    var successMessageDiv = document.getElementById("success");
    var amountLeftMessageDiv = document.getElementById("amountleft");
    var itemMessageDiv = document.getElementById("items");

    if (clickedId == "Cola") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 2;
        var count = 4;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Cola ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Cola to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    } else if (clickedId == "Coke") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 3;
        var count = 6;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Coke ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Coke to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    } else if (clickedId == "Pepper") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 1;
        var count = 4;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Pepper ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Pepper to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    } else if (clickedId == "Sprite") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 1;
        var count = 4;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Sprite ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Sprite to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    } else if (clickedId == "Fanta") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 3;
        var count = 5;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Fanta ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Fanta to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    } else if (clickedId == "Ginger") {
        //As we have no external database so taken inmemory product details (name, price and quantity)
        var price = 1;
        var count = 5;
        if (coinAmount >= price) {
            coinAmount = coinAmount - price
            document.getElementById("success").innerHTML = Message;
            document.getElementById("amountleft").innerHTML = "you are left with Amount :" + coinAmount;
            count = count - 1;
            list.push('Ginger ');
            document.getElementById("items").innerHTML = "list of products :" + list.join("");
            document.getElementById("Coin").value = '';
            successMessageDiv.style.display = "block";
            amountLeftMessageDiv.style.display = "block";
            itemMessageDiv.style.display = "block";
            errorMessageDiv.style.display = "none";
        } else {
            var insuffBal = "Insufficient amount, ";
            document.getElementById("Error").innerHTML = insuffBal + "Please insert more than $" + price + " and click on Ginger to purchase";
            if (errorMessageDiv.style.display === "none") {
                errorMessageDiv.style.display = "block";
                successMessageDiv.style.display = "none";
                amountLeftMessageDiv.style.display = "none";
                itemMessageDiv.style.display = "none";
            }
        }
    }
}  